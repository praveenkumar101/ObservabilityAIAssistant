#!/usr/bin/env python3
"""AI Observability Assistant - Final Demo
Features:
- Pluggable retrieval adapter: 'tf' or 'mock_embeddings' (switch in UI)
- Slack message simulator: paste a Slack message and simulate assistant response
Run: python observability_demo_final.pyz
"""
INTRO = 'AI-Powered Observability Knowledge Base Assistant\n(Extract from provided documentation)\n\nProblem: Engineers face alert fatigue, siloed knowledge, and long MTTR due to scattered logs, runbooks, and incident data.\nSolution: An AI assistant that uses LLM + RAG over logs, runbooks and incident history to recommend context-aware resolutions via Slack/Teams and a web dashboard.\nDemo workflow: Engineer reports issue -> Assistant searches historical incidents -> Suggested resolution + runbook link -> Engineer applies fix and exports resolution log.\nSuccess metrics targeted: 30–40% MTTR reduction; high adoption; 60% incidents resolved via AI suggestions.\n'

RUNBOOKS = [{"id": "rb_auth_timeout", "title": "Auth Service Timeout Runbook", "link": "https://company.runbooks/auth-timeout", "keywords": ["timeout", "504", "auth", "auth-client"], "steps": "1) Roll back recent auth client change\n2) Increase timeout to 10s\n3) Clear auth cache\n4) Monitor 5xx rate for 10m"}, {"id": "rb_db_deadlock", "title": "DB Deadlock Mitigation", "link": "https://company.runbooks/db-deadlock", "keywords": ["deadlock", "database", "transaction"], "steps": "1) Identify conflicting transactions\n2) Restart worker pool\n3) Apply DB index fix and retry jobs"}, {"id": "rb_latency", "title": "Latency Troubleshooting", "link": "https://company.runbooks/latency-troubleshoot", "keywords": ["latency", "slow", "slowness"], "steps": "1) Check slow queries\n2) Inspect tracing spans\n3) Scale out service replicas"}, {"id": "rb_memory", "title": "Memory Leak Investigation", "link": "https://company.runbooks/memory-leak", "keywords": ["memory", "oom", "outofmemory"], "steps": "1) Capture heap profiles\n2) Restart affected pods\n3) Pinpoint leak and patch"}, {"id": "rb_general", "title": "General Incident Playbook", "link": "https://company.runbooks/general-incident", "keywords": ["error", "fail", "exception", "incident"], "steps": "1) Gather logs & traces\n2) Run common remediation steps\n3) Escalate to on-call"}]

SAMPLE_INCIDENTS = [{"id": "sample_payment", "title": "Payment gateway - 504 Timeout after deploy", "text": "Service: payment-gateway\nTimestamp: 2025-08-21 14:12:33\nSymptoms: High 5xx error rate...\nLogs: 'ERROR: payment_processor - Timeout when calling /auth - status=504'\nImpact: Checkout failures"}, {"id": "sample_db", "title": "Order-service DB deadlocks", "text": "Service: order-service\nTimestamp: 2025-07-11 09:22:10\nSymptoms: Jobs failing with deadlock detected\nLogs: 'deadlock detected'\nImpact: Order delays"}]

import tkinter as tk
from tkinter import scrolledtext, messagebox, ttk
import re, os, datetime, math, json, random

def tokenize(text):
    return re.findall(r"\w+", text.lower())

def tf_vector(tokens):
    tf = {}
    for t in tokens:
        tf[t] = tf.get(t,0) + 1
    return tf

def cosine_sim(a,b):
    dot = 0
    for k,v in a.items():
        dot += v * b.get(k,0)
    na = math.sqrt(sum(v*v for v in a.values()))
    nb = math.sqrt(sum(v*v for v in b.values()))
    if na==0 or nb==0: return 0.0
    return dot/(na*nb)

def retrieve_tf(text):
    v = tf_vector(tokenize(text))
    best = (None,0.0)
    for rb in RUNBOOKS:
        corpus = ' '.join([rb['title'], rb['steps']] + rb.get('keywords',[]))
        vec = tf_vector(tokenize(corpus))
        s = cosine_sim(v, vec)
        if s > best[1]:
            best = (rb, s)
    return best if best[0] else ({'title':'General Incident Playbook','link':'https://company.runbooks/general-incident','steps':'1) Gather logs & traces...'},0.0)

def retrieve_mock_embeddings(text):
    txt = text.lower()
    for rb in RUNBOOKS:
        for kw in rb.get('keywords',[]):
            if kw in txt:
                return (rb, 0.9)
    rb = random.choice(RUNBOOKS)
    return (rb, 0.2)

def severity_score(text):
    errs = sum(1 for _ in re.finditer(r'\b(error|fail|timeout|5xx|504|exception|panic|oom|deadlock)\b', text.lower()))
    if errs >= 3: return 'High'
    if errs == 2: return 'Medium'
    return 'Low'

def suggest(adapter, text):
    if adapter == 'tf':
        rb, sim = retrieve_tf(text)
    else:
        rb, sim = retrieve_mock_embeddings(text)
    sev = severity_score(text)
    suggestion = f"Severity: {sev}\nSimilarity: {sim:.3f}\nRunbook: {rb['title']}\nLink: {rb['link']}\nSteps:\n{rb['steps']}"
    return suggestion, rb

def export_report(incident, suggestion, runbook):
    now = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    fname = f"observability_report_{now}.txt"
    with open(fname,'w',encoding='utf-8') as f:
        f.write('AI Observability Assistant - Demo Report\n')
        f.write('Generated: ' + datetime.datetime.now().isoformat() + '\n\n')
        f.write('=== Incident ===\n' + incident + '\n\n')
        f.write('=== Suggestion ===\n' + suggestion + '\n\n')
        f.write('=== Runbook ===\n' + runbook['title'] + ' - ' + runbook['link'] + '\n')
    return os.path.abspath(fname)

def create_gui():
    root = tk.Tk()
    root.title('AI Observability Assistant - Final Demo')
    root.geometry('1000x800')
    frame = tk.Frame(root,padx=8,pady=8); frame.pack(fill='both',expand=True)

    title = tk.Label(frame,text='AI Observability Assistant — Final Demo',font=('Helvetica',16,'bold')); title.pack(anchor='w')
    intro = scrolledtext.ScrolledText(frame,height=6); intro.insert('1.0',INTRO); intro.configure(state='disabled'); intro.pack(fill='x',pady=(4,8))

    adapter_frame = tk.Frame(frame); adapter_frame.pack(fill='x', pady=(0,8))
    tk.Label(adapter_frame,text='Retrieval adapter:').pack(side='left')
    adapter_var = tk.StringVar(value='tf')
    tk.Radiobutton(adapter_frame,text='TF (local)',variable=adapter_var,value='tf').pack(side='left',padx=6)
    tk.Radiobutton(adapter_frame,text='Mock embeddings',variable=adapter_var,value='mock').pack(side='left',padx=6)

    sim_frame = tk.Frame(frame); sim_frame.pack(fill='x', pady=(0,8))
    tk.Label(sim_frame,text='Slack message simulator: paste a message and click "Simulate Slack"').pack(anchor='w')
    slack_box = scrolledtext.ScrolledText(frame,height=4); slack_box.pack(fill='x', pady=(0,6))
    tk.Label(frame,text='Or paste a detailed incident (logs) below:').pack(anchor='w')
    incident_box = scrolledtext.ScrolledText(frame,height=10); incident_box.pack(fill='x', pady=(0,8))

    sel_frame = tk.Frame(frame); sel_frame.pack(fill='x', pady=(0,8))
    tk.Label(sel_frame,text='Load sample incident:').pack(side='left')
    combo = ttk.Combobox(sel_frame, values=[s['title'] for s in SAMPLE_INCIDENTS], state='readonly', width=60); combo.pack(side='left',padx=6)
    def load_sample(e=None):
        sel = combo.get()
        for s in SAMPLE_INCIDENTS:
            if s['title'] == sel:
                incident_box.delete('1.0',tk.END); incident_box.insert('1.0',s['text']); return
    combo.bind('<<ComboboxSelected>>', load_sample)

    btn_frame = tk.Frame(frame); btn_frame.pack(fill='x', pady=(0,8))
    def simulate_slack():
        msg = slack_box.get('1.0',tk.END).strip()
        if not msg: messagebox.showinfo('Empty', 'Paste a Slack message to simulate.'); return
        incident_box.delete('1.0',tk.END); incident_box.insert('1.0', msg); do_suggest()
    tk.Button(btn_frame,text='Simulate Slack', command=simulate_slack).pack(side='left',padx=6)
    tk.Button(btn_frame,text='Suggest resolution', command=lambda: do_suggest()).pack(side='left',padx=6)
    tk.Button(btn_frame,text='Export report', command=lambda: do_export()).pack(side='left',padx=6)

    output = scrolledtext.ScrolledText(frame,height=16); output.configure(state='disabled'); output.pack(fill='both',expand=True,pady=(8,0))

    def do_suggest():
        txt = incident_box.get('1.0',tk.END).strip()
        if not txt: messagebox.showinfo('Empty','Paste incident or simulate Slack first.'); return
        adapter = adapter_var.get(); adapter_key = 'mock' if adapter=='mock' else 'tf'
        suggestion, rb = suggest(adapter_key, txt)
        output.configure(state='normal'); output.delete('1.0',tk.END)
        output.insert('1.0', '=== Suggested Resolution ===\n' + suggestion + '\n\n=== Runbook ===\n' + rb['title'] + ' -> ' + rb['link'])
        output.configure(state='disabled')

    def do_export():
        txt = incident_box.get('1.0',tk.END).strip()
        if not txt: messagebox.showinfo('Empty','Paste incident or simulate Slack first.'); return
        adapter = adapter_var.get(); adapter_key = 'mock' if adapter=='mock' else 'tf'
        suggestion, rb = suggest(adapter_key, txt)
        saved = export_report(txt, suggestion, rb)
        messagebox.showinfo('Saved', 'Report saved to: ' + saved)

    root.mainloop()

if __name__ == '__main__':
    create_gui()
