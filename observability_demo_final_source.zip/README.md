AI Observability Assistant - Final Demo
======================================
This final demo includes:
- Pluggable retrieval adapters ('tf' and 'mock_embeddings')
- Slack message simulator UI
- Exportable incident reports
- GitHub Actions workflow to build Windows .exe (included in source zip)
